            $(function () {
                $('.filter').filterizr();
            });

            $(document).ready(function(){
                $('.slider-wraper').slick({
                    dots:true,
                    arrow:true
                });
            });
            