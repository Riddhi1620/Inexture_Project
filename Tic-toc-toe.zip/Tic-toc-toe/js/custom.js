var pos=[0,0,0,0,0,0,0,0,0];

function btnclick(btnObj)
{   
    var id=btnObj.id;
    console.log(id);
    alert("hello");
}