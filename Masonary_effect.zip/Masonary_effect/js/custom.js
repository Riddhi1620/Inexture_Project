
$('.grid').masonry({
    // options
    itemSelector: '.grid-item',
    columnWidth: '.grid-item',
    gutter: 20,
    percentPosition: true
  });


